#!/bin/bash
#
# Removes the module from the list of loaded modules.
# Must be run as root.
#

rmmod rootkit
