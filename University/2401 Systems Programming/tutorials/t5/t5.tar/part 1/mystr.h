#ifndef MYSTRCMP
#define MYSTRCMP

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int myStrCmp(char *s1, char *s2);

#endif
