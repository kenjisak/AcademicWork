Kenji Isak Laguan
101160737
printTriangles.c

compile each file by making sure youre in the right directory as the source files. for example if the files are in the desktop , run the gnome-terminal and type in cd Desktop and hit enter to be in the desktop directory. 
once in the right directory type into the terminal gcc -o (source filename only) (source file name.c) and hit enter(for example gcc -o printTriangles printTriangles.c) this is to compile the code. after that to run the code you need to type in the terminal ./(file name only) for example ./printTriangles
