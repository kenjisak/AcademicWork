#ifndef DEFS_H
#define DEFS_H

#define MAX_EPS 100
#define MAX_PODS 100
#define MAX_SUBS 100

#endif
